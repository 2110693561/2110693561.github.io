# 技术笔记博客 v1

一个以 GitHub 为内容仓库的个人技术博客第一版。

## 技术栈

- Astro：博客前台
- Markdown：文章格式
- Decap CMS：网页管理后台
- GitHub：文章版本控制
- GitHub Pages：静态部署
- Cloudflare Worker：GitHub OAuth 登录代理

Astro 官方支持通过 GitHub Actions 部署到 GitHub Pages。
Decap CMS 可以使用 GitHub backend 管理 GitHub 仓库中的内容。

## 本地运行

需要 Node.js 22+。

```bash
npm install
npm run dev
```

然后打开：

http://localhost:4321

管理后台：

http://localhost:4321/admin/

## 第一次配置

### 1. 创建 GitHub 仓库

例如：

`tech-notes-blog`

### 2. 修改

`astro.config.mjs`

把：

```js
site: "https://YOUR_USERNAME.github.io",
base: "/YOUR_REPO",
```

改成你的 GitHub 用户名和仓库名。

### 3. 修改 CMS

编辑：

`public/admin/config.yml`

把：

```yaml
repo: YOUR_USERNAME/YOUR_REPO
site_url: "https://YOUR_USERNAME.github.io/YOUR_REPO"
```

改成真实仓库。

### 4. GitHub Pages

仓库 Settings → Pages → Source 选择 GitHub Actions。

推送到 main 后会自动构建。

### 5. 管理后台登录

GitHub backend 需要 OAuth 服务端。GitHub 官方限制决定了纯静态 GitHub Pages 不能自己安全保存 OAuth client secret。

本项目提供：

`oauth-worker/`

用于部署 Cloudflare Worker。

完成 OAuth 后，访问：

`https://你的博客地址/admin/`

即可出现文章管理界面。

## 后台可以做什么

- 新建文章
- 编辑文章
- 删除文章
- 草稿
- 发布
- 分类
- 标签
- Markdown 编辑
- 图片上传
- Editorial workflow
- GitHub commit / PR 版本记录

## 下一版

准备加入：

- 搜索
- 标签页
- 分类页
- 项目展示
- 图片画廊
- 网站设置
- 访问统计
- RSS
- SEO
- 评论系统
- 更完整的后台仪表盘
