---
title: "第一篇：把 GitHub 做成自己的技术知识库"
description: "这个博客的第一篇文章，记录建站思路与后续规划。"
date: "2026-09-01"
category: "博客"
tags:
  - GitHub
  - Markdown
  - 博客
---

# 为什么做这个博客

以前遇到的问题经常散落在聊天记录、终端和临时文件里。

现在把它们统一整理成 Markdown，并交给 Git 管理。

## 后续规划

- ESP32 / ESP32-S3
- GD32
- FreeRTOS
- Linux / WSL / Docker
- OpenClaw
- BLE
- Apple Find My 学习记录

以后每解决一个问题，就写成一篇文章。
