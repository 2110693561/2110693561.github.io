import { defineConfig } from "astro/config";

export default defineConfig({
  site: "https://YOUR_USERNAME.github.io",
  base: "/YOUR_REPO",
  output: "static"
});
